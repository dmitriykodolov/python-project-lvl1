#!/usr/bin/env python3
from brain_games.games.calc import quiz_calc


def main():
    quiz_calc()


if __name__ == '__main__':
    main()
