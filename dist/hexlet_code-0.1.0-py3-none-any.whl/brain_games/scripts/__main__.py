import brain_games

main()
